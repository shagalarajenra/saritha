package com.customer.demo.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.customer.demo.model.*;
import com.customer.demo.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class UserController {

	@Autowired
	private UserService service;

	@Autowired
	private HttpSession session;

	@GetMapping("/admin")
	public String home() {
		return "home";
	}

	@GetMapping("/")
	public String user() {
		return "home2";
	}

	@GetMapping("/logout")
	public String logout() {
		session.invalidate();
		return "home2";
	}

	@PostMapping("/logout2")
	public String logout2() {
		session.invalidate();
		return "home2";
	}

	@GetMapping("/customer")
	public String customer(Model model) {
		model.addAttribute("messahe", "click here");
		return "customer";
	}

	@RequestMapping(value = "/createProduct", method = RequestMethod.POST)
	public String createProduct(Model model) {
		List<Category> list = new ArrayList<>();
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		model.addAttribute("categories", categories1);
		return "createProduct";
	}

	@RequestMapping(value = "/products", method = RequestMethod.POST)
	public String products(@RequestParam String name, @RequestParam String description, @RequestParam double price,
			@RequestParam int category, Model model) {
		Optional<Category> category1 = service.findById(category);
		Product pro = new Product();
		pro.setName(name);
		pro.setDescription(description);
		pro.setPrice(price);
		pro.setCategory(category1.get());
		String message = service.save(pro);

		List<Category> list = new ArrayList<>();
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		model.addAttribute("categories", categories1);
		
		if(message.equalsIgnoreCase("fail")) {
			model.addAttribute("message", "already");
		}else {
		model.addAttribute("message", "success");
		}
		return "createProduct";
	}

	@RequestMapping(value = "/createCategory", method = RequestMethod.POST)
	public @ResponseBody String createCategory(Model model, @RequestParam("name") String name) {
		Category category = new Category();
		category.setName(name);
		service.save(category);
		List<Category> list = new ArrayList<>();
		String categories = null;
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);

		ObjectMapper objectMapper = new ObjectMapper();

		try {
			categories = objectMapper.writeValueAsString(list);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return categories;
	}

	@PostMapping("/adminLogin")
	public String adminLogin(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model) {
		if (username.equalsIgnoreCase("admin") && password.equalsIgnoreCase(password)) {
			session.setAttribute("username", username);
			return "employee";
		} else {

			model.addAttribute("message", "Invalid Credentials");
			return "home2";
		}
	}

	@GetMapping("/adminLogin2")
	public String adminLogin(Model model) {
		return "employee";
	}

	@PostMapping("/userLogin")
	public String userLogin(@RequestParam("username") String username, @RequestParam("password") String password,
			@RequestParam("role") String role, Model model) {
		Customer customer = null;
		Employee employee = null;
		if (role.equalsIgnoreCase("customer")) {
			customer = service.findCustomer(username, password);
		} else if(role.equalsIgnoreCase("employee")){
			employee = service.findEmployee(username, password);
		}
		else {
			if (username.equalsIgnoreCase("admin") && password.equalsIgnoreCase(password)) {
				session.setAttribute("username", username);
				return "employee";
			} else {

				model.addAttribute("message", "Invalid Credentials");
				return "home2";
			}
		}

		if (customer == null && employee == null) {
			model.addAttribute("message", "Invalid credentials");
			return "home2";
		} else if (customer != null) {
			session.setAttribute("user", customer);
			List<Order> list = service.findAllOrderByCustomerId(customer.getId());
			model.addAttribute("list", list);
			return "order";
		} else {

			List<Order> listMain = new ArrayList<>();
			Iterable<Order> list = service.findAllOrders();
			list.iterator().forEachRemaining(listMain::add);
			model.addAttribute("list", listMain);
			return "order2";
		}
	}

	@GetMapping("/userLogin2")
	public String userLogin(Model model) {
		Customer customer = (Customer) session.getAttribute("user");
		List<Order> list = service.findAllOrderByCustomerId(customer.getId());
		model.addAttribute("list", list);
		return "order";

	}
	
	@GetMapping("/userLogin3")
	public String userLogin3(Model model) {
		
		List<Order> listMain = new ArrayList<>();
		Iterable<Order> list = service.findAllOrders();
		list.iterator().forEachRemaining(listMain::add);
		model.addAttribute("list", listMain);
		return "order2";

	}

	@GetMapping("/updatePro")
	public String updatePro(Model model, @RequestParam int id) {
		Optional<Order> order = service.findByIdOrderId(id);
		List<Category> list = new ArrayList<>();
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		session.setAttribute("id", id);
		model.addAttribute("categories", categories1);

		model.addAttribute("customer", order.get().getCustomer());
		model.addAttribute("product", order.get().getOrderItems().getProduct());
		model.addAttribute("quantity", order.get().getOrderItems().getQuantity());
		model.addAttribute("price", order.get().getOrderItems().getPrice());

		return "newOrder2";
	}

	@GetMapping("/updatePro2")
	public String updatePro2(Model model, @RequestParam int id) {
		Optional<Order> order = service.findByIdOrderId(id);
		session.setAttribute("user", order.get());
		List<Category> list = new ArrayList<>();
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		session.setAttribute("id", id);
		model.addAttribute("categories", categories1);

		model.addAttribute("customer", order.get().getCustomer());
		model.addAttribute("product", order.get().getOrderItems().getProduct());
		model.addAttribute("quantity", order.get().getOrderItems().getQuantity());
		model.addAttribute("price", order.get().getOrderItems().getPrice());
		model.addAttribute("orderStatus", order.get().getOrderStatus());

		return "newOrderEmployee";
	}

	@GetMapping("/deletePro")
	public String deletePro(Model model, @RequestParam int id) {
		Customer cus = (Customer) session.getAttribute("user");
		service.deleteById(id);
		List<Order> list = service.findAllOrderByCustomerId(cus.getId());
		model.addAttribute("list", list);

		return "order";
	}
	
	@GetMapping("/deletePro2")
	public String deletePro2(Model model, @RequestParam int id) {
		
		service.deleteById(id);
		List<Order> listMain = new ArrayList<>();
		Iterable<Order> list = service.findAllOrders();
		list.iterator().forEachRemaining(listMain::add);
		model.addAttribute("list", listMain);
		return "order2";

	}

	@PostMapping("/empRegister")
	public String empRegister(Model model, @ModelAttribute Employee employee) {

		LocalDate localdate = LocalDate.parse(employee.getDate());
		employee.setHireDate(localdate);
		employee.setRole("Employee");
		String em = service.save(employee);
		if (em.equalsIgnoreCase("success")) {
			model.addAttribute("message", "success");
			return "employee";
		} else {
			model.addAttribute("message", "fail");
			return "employee";
		}

	}

	@PostMapping("/addCustomer")
	public String addCustomer(Model model, @ModelAttribute Customer customer) {

		String message = service.save(customer);
		if (message.equalsIgnoreCase("success")) {
			model.addAttribute("msg", "Added successfully. Now you can login here");
			return "customer";
		} else {
			model.addAttribute("message", "fail");
			return "customer";
		}

	}

	@GetMapping("/newOrder")
	public String newOrder(Model model) {

		List<Category> list = new ArrayList<>();
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		model.addAttribute("categories", categories1);
		return "newOrder";
	}

	@GetMapping("/newOrder2")
	public String newOrder2(Model model, @RequestParam int id) {

		List<Category> list = new ArrayList<>();
		Optional<Order> order = service.findByIdOrderId(id);
		session.setAttribute("user", order);
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		model.addAttribute("categories", categories1);
		return "newOrderEmployee";
	}

	@RequestMapping(value = "/getProducts", method = RequestMethod.POST)
	public @ResponseBody String newOrder(@RequestParam int name) {

		List<Product> list = service.getProduct(name);
		String pros = null;

		ObjectMapper objectMapper = new ObjectMapper();

		try {
			pros = objectMapper.writeValueAsString(list);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return pros;
	}

	@PostMapping("/orderPlacement")
	public String placeOrder(@RequestParam("customer") int customer, @RequestParam("product") String product,
			@RequestParam("quantity") int quantity, @RequestParam("price") double price,
			@RequestParam("category") double category, Model model) {

		String[] str = product.split("_", 2);
		Optional<Product> product1 = service.findByName(Integer.valueOf(str[0]));

		Optional<Customer> customer1 = service.getCustomerById(customer);

		OrderItem orderItem = new OrderItem();
		orderItem.setProduct(product1.get());
		orderItem.setQuantity(quantity);
		orderItem.setPrice(price);

		Invoice in = new Invoice();
		in.setInvoiceDate(LocalDate.now());
		in.setPaidAmount(price);
		in.setTotalAmount(price);

		Order order = new Order();
		order.setCustomer(customer1.get());
		order.setOrderStatus("Order received");
		order.setOrderDate(LocalDate.now());
		order.setTotalAmount(orderItem.getPrice());
		order.setOrderItems(orderItem);
		order.setInvoice(in);

		orderItem.setOrder(order);
		in.setOrder(order);
		service.save(order);

		List<Category> list = new ArrayList<>();
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		model.addAttribute("categories", categories1);
        model.addAttribute("message", "success");
		
		return "newOrder";
	}

	@PostMapping("/orderPlacement2")
	public String orderPlacement2(@RequestParam("customer") int customer, @RequestParam("product") String product,
			@RequestParam("quantity") int quantity, @RequestParam("price") double price,
			@RequestParam("category") double category, Model model) {

		Integer id = Integer.parseInt(String.valueOf(session.getAttribute("id")));
		String[] str = product.split("_", 2);
		Optional<Product> product1 = service.findByName(Integer.valueOf(str[0]));

		Optional<Customer> customer1 = service.getCustomerById(customer);
		Optional<Order> order = service.findByIdOrderId(id);

		OrderItem orderItem = service.findByOrderIdforOrderItem(order.get().getId());
		orderItem.setProduct(product1.get());
		orderItem.setQuantity(quantity);
		orderItem.setPrice(price);

		Invoice in = service.findByOrderIdforInvoice(order.get().getId());
		in.setInvoiceDate(LocalDate.now());
		in.setPaidAmount(price);
		in.setTotalAmount(price);

		order.get().setCustomer(customer1.get());
		order.get().setOrderStatus("Order received");
		order.get().setOrderDate(LocalDate.now());
		order.get().setTotalAmount(orderItem.getPrice());
		order.get().setOrderItems(orderItem);
		order.get().setInvoice(in);

		orderItem.setOrder(order.get());
		in.setOrder(order.get());
		service.save(order.get());

		List<Category> list = new ArrayList<>();
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		model.addAttribute("categories", categories1);
       
		model.addAttribute("customer", order.get().getCustomer());
		model.addAttribute("product", order.get().getOrderItems().getProduct());
		model.addAttribute("quantity", order.get().getOrderItems().getQuantity());
		model.addAttribute("price", order.get().getOrderItems().getPrice());
		model.addAttribute("message", "success");
		return "newOrder2";
	}
	
	
	@PostMapping("/orderPlacement3")
	public String orderPlacement3(@RequestParam("customer") int customer, @RequestParam("product") String product,
			@RequestParam("quantity") int quantity, @RequestParam("price") double price,
			@RequestParam("category") double category,@RequestParam String orderStatus, Model model) {

		Integer id = Integer.parseInt(String.valueOf(session.getAttribute("id")));
		String[] str = product.split("_", 2);
		Optional<Product> product1 = service.findByName(Integer.valueOf(str[0]));

		Optional<Customer> customer1 = service.getCustomerById(customer);
		Optional<Order> order = service.findByIdOrderId(id);

		OrderItem orderItem = service.findByOrderIdforOrderItem(order.get().getId());
		orderItem.setProduct(product1.get());
		orderItem.setQuantity(quantity);
		orderItem.setPrice(price);

		Invoice in = service.findByOrderIdforInvoice(order.get().getId());
		in.setInvoiceDate(LocalDate.now());
		in.setPaidAmount(price);
		in.setTotalAmount(price);

		order.get().setCustomer(customer1.get());
		order.get().setOrderStatus(orderStatus);
		order.get().setOrderDate(LocalDate.now());
		order.get().setTotalAmount(orderItem.getPrice());
		order.get().setOrderItems(orderItem);
		order.get().setInvoice(in);

		orderItem.setOrder(order.get());
		in.setOrder(order.get());
		service.save(order.get());

		List<Category> list = new ArrayList<>();
		Iterable<Category> categories1 = service.findAllCategories();
		categories1.iterator().forEachRemaining(list::add);
		model.addAttribute("categories", categories1);
       
		model.addAttribute("customer", order.get().getCustomer());
		model.addAttribute("product", order.get().getOrderItems().getProduct());
		model.addAttribute("quantity", order.get().getOrderItems().getQuantity());
		model.addAttribute("price", order.get().getOrderItems().getPrice());
		model.addAttribute("orderStatus", order.get().getOrderStatus());
		model.addAttribute("message", "success");
		return "newOrderEmployee";
	}
}
