package com.customer.demo.model;

import java.time.LocalDate;

import javax.persistence.*;

import lombok.Data;


@Entity
@Table(name = "invoice")
@Data
public class Invoice {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @OneToOne
    @JoinColumn(name = "order_id")
    private Order order;
    
    @Column(name = "invoice_date")
    private LocalDate invoiceDate;
    
    @Column(name = "total_amount")
    private Double totalAmount;
    
    @Column(name = "paid_amount")
    private Double paidAmount;
    
   
}
