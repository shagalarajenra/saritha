package com.customer.demo.model;

import java.time.LocalDate;
import javax.persistence.*;

import lombok.Data;

@Entity
@Table(name = "orders")
@Data
public class Order {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;
        
    @Column(name = "order_date")
    private LocalDate orderDate;
    
    @Column(name = "total_amount")
    private Double totalAmount;
    
    @Column(name = "order_status")
    private String orderStatus;
    
    @OneToOne(mappedBy = "order",cascade = CascadeType.ALL)
    private OrderItem orderItems;
    
    @OneToOne(mappedBy = "order",cascade = CascadeType.ALL)
    private Invoice invoice;
    
    
}
