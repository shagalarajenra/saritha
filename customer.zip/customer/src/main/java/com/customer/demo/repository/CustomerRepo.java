package com.customer.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.customer.demo.model.Customer;

@Repository
public interface CustomerRepo extends CrudRepository<Customer, Integer> {

	 Customer findByNameAndEmail(String username, String password);

}
