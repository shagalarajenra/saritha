package com.customer.demo.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.customer.demo.model.Invoice;

@Repository
public interface InterfaceRepository extends CrudRepository<Invoice, Integer> {

	@Query(value="select * from invoice where order_id=?1" , nativeQuery = true)
	Invoice findByOrderId(Integer id);

}
