package com.customer.demo.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.customer.demo.model.OrderItem;

@Repository
public interface OrderItemRepository extends CrudRepository<OrderItem, Integer> {

	@Query(value="select * from order_item where order_id=?1" , nativeQuery = true)
	OrderItem findByOrderId(Integer id);

}
