package com.customer.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.customer.demo.model.Order;

@Repository
public interface OrderRepo extends CrudRepository<Order, Integer> {

	@Query(value="select * from orders where customer_id=?1",nativeQuery = true)
	List<Order> findByCustomer(Integer id);

}
