package com.customer.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.customer.demo.model.Product;

@Repository
public interface ProductRepo extends CrudRepository<Product, Integer> {

	@Query(value="select * from product where category_id=?1" , nativeQuery = true)
	List<Product> getProducts(Integer integer);

	Product findByName(String productName);

}
