package com.customer.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.demo.model.Category;
import com.customer.demo.model.Customer;
import com.customer.demo.model.Employee;
import com.customer.demo.model.Invoice;
import com.customer.demo.model.Order;
import com.customer.demo.model.OrderItem;
import com.customer.demo.model.Product;
import com.customer.demo.repository.CategoryRepo;
import com.customer.demo.repository.CustomerRepo;
import com.customer.demo.repository.EmployeeRepo;
import com.customer.demo.repository.InterfaceRepository;
import com.customer.demo.repository.OrderItemRepository;
import com.customer.demo.repository.OrderRepo;
import com.customer.demo.repository.ProductRepo;

@Service
public class UserService {

	@Autowired
	private EmployeeRepo repo;
	@Autowired
	private CustomerRepo customerRepo;
	@Autowired
	private CategoryRepo categoryRepo;
	@Autowired
	private ProductRepo productRepo;
	@Autowired
	private OrderRepo orderRepo;
	@Autowired
	private OrderItemRepository orderItemRepository;
	@Autowired
	private InterfaceRepository interfaceRepository;

	public String save(Employee employee) {
		try {
		repo.save(employee);
		return "success";
		}catch(Exception e) {
			return "fail";
		}
		
	}

	public String save(Customer customer) {
		try {
	    customerRepo.save(customer);
	    return "success";
		}
		catch(Exception e){
			 return "fail";
		}
		
	}

	public Employee findEmployee(String username, String password) {
		return repo.findByNameAndEmail(username, password);

	}

	public Customer findCustomer(String username, String password) {
		return customerRepo.findByNameAndEmail(username, password);

	}

	public void save(Category category) {
		categoryRepo.save(category);		
	}

	public Iterable<Category> findAllCategories() {
		return categoryRepo.findAll();

	}

	public String save(Product product) {
		try {
		productRepo.save(product);
		return "success";
		}
		catch(Exception e) {
			return "fail";
		}

	}

	public Optional<Category> findById(int category) {
		return categoryRepo.findById(category);
	}

	public List<Product> getProduct(Integer integer) {
		return productRepo.getProducts(integer);
	}

	public Optional<Product> findByName(int product) {
		return productRepo.findById(product);
	}

	public Optional<Customer> getCustomerById(int customer) {
		return customerRepo.findById(customer);
		
	}

	public void save(Order order) {
		orderRepo.save(order);
	}

	public void save(OrderItem orderItem) {
		orderItemRepository.save(orderItem);
		
	}

	public void save(Invoice in) {
		interfaceRepository.save(in);
		
	}

	public List<Order> findAllOrderByCustomerId(Integer id) {
		return orderRepo.findByCustomer(id);
		
	}

	public Optional<Order> findByIdOrderId(int id) {
		return orderRepo.findById(id);
		
	}

	public Invoice findByOrderIdforInvoice(Integer id) {
		return interfaceRepository.findByOrderId(id);
		
	}

	public OrderItem findByOrderIdforOrderItem(Integer id) {
		
		return orderItemRepository.findByOrderId(id);
	}

	public void deleteById(int id) {
		orderRepo.deleteById(id);
	}

	public Iterable<Order> findAllOrders() {
		return orderRepo.findAll();
	}

}
